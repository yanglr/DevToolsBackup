﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //List<Customer> custs = new List<Customer>
            //{
            //    new Customer{CustomerID=1,FirstName="John",LastName="Doe",Address="Phoenix"},
            //    new Customer{CustomerID=1,FirstName="Jane",LastName="Doe",Address="Phoenix"},
            //    new Customer{CustomerID=1,FirstName="Tim",LastName="Doe",Address="Las Vegas"},
            //    new Customer{CustomerID=1,FirstName="Tina",LastName="Doe",Address="Los Angeles"}
            //};
            //var filteredCusts = from c in custs
            //                    where c.FirstName.StartsWith("T") &&
            //                    c.Address == "Las Vegas"
            //                    select new { Name = c.FirstName + " " + c.LastName };
            //Lambda expression
            //var filteredCusts = custs.Where(c => c.Address.StartsWith("P"));
            //foreach (var item in filteredCusts)
            //{
            //    Console.WriteLine(item.FirstName);
            //}
            //using (Data.NorthwindDataContext context = new Data.NorthwindDataContext())
            //{
            //    var customers = from c in context.Customers
            //                    where c.Country == "USA"
            //                    select c;
            //    foreach (var item in customers)
            //    {
            //        Console.WriteLine(item.ContactName);
            //    }
            //}
            using (Data.NorthwindDataContext context = new Data.NorthwindDataContext())
            {
                var sprocCustomers = context.ap_GetCustomersByCountry("USA");
                foreach (var item in sprocCustomers)
                {
                    Console.WriteLine(item.ContactName);
                }
            }


            Console.Read();

        }
    }

    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }

    }
}
