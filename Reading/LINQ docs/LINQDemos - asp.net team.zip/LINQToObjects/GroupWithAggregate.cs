﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Data;
using System.Text;
using System.Globalization;

namespace LinqToDataSet
{
    public class GroupWithAggregate
    {
        public static void Main()
        {
            // Fill the DataSet.
            DataSet ds = new DataSet();
            ds.Locale = CultureInfo.InvariantCulture;
            DAL.FillDataSet(ds);

            var products = ds.Tables["Product"].AsEnumerable();

            var query = from product in products
                        group product by product.Field<string>("Style") into g
                        select new
                        {
                            Style = g.Key,
                            AverageListPrice =
                                g.Average(product => product.Field<Decimal>("ListPrice"))
                        };

            foreach (var product in query)
            {
                Console.WriteLine("Product style: {0} Average list price: {1}",
                    product.Style, product.AverageListPrice);
            }

            Console.Read();
        }
    }
}
