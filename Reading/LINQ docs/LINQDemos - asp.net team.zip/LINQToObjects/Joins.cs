﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Data;
using System.Text;
using System.Globalization;

namespace LinqToDataSet
{
    class Joins
    {
        static void Main(string[] args)
        {
            // Fill the DataSet.
            DataSet ds = new DataSet();
            ds.Locale = CultureInfo.InvariantCulture;
            DAL.FillDataSet(ds);

            var orders = ds.Tables["SalesOrderHeader"].AsEnumerable();
            var details = ds.Tables["SalesOrderDetail"].AsEnumerable();

            var query =
                from order in orders
                join detail in details
                on order.Field<int>("SalesOrderID")
                equals detail.Field<int>("SalesOrderID") into ords
                select new
                {
                    CustomerID =
                        order.Field<int>("SalesOrderID"),
                    ords = ords.Count()
                };

            foreach (var order in query)
            {
                Console.WriteLine("CustomerID: {0}  Orders Count: {1}",
                    order.CustomerID,
                    order.ords);
            }

            Console.Read();
        }
    }
}
