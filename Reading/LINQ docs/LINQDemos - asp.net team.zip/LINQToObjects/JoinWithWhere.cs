﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Data;
using System.Text;
using System.Globalization;

namespace LinqToDataSet
{
    public class JoinWithWhere
    {
        public static void Main()
        {
            // Fill the DataSet.
            DataSet ds = new DataSet();
            ds.Locale = CultureInfo.InvariantCulture;
            DAL.FillDataSet(ds);

            DataTable orders = ds.Tables["SalesOrderHeader"];
            DataTable details = ds.Tables["SalesOrderDetail"];

            var query =
                from order in orders.AsEnumerable()
                join detail in details.AsEnumerable()
                on order.Field<int>("SalesOrderID") equals
                    detail.Field<int>("SalesOrderID")
                where order.Field<bool>("OnlineOrderFlag") == true
                && order.Field<DateTime>("OrderDate").Month == 8
                select new
                {
                    SalesOrderID =
                        order.Field<int>("SalesOrderID"),
                    SalesOrderDetailID =
                        detail.Field<int>("SalesOrderDetailID"),
                    OrderDate =
                        order.Field<DateTime>("OrderDate"),
                    ProductID =
                        detail.Field<int>("ProductID")
                };


            foreach (var order in query)
            {
                Console.WriteLine("{0}\t{1}\t{2:d}\t{3}",
                    order.SalesOrderID,
                    order.SalesOrderDetailID,
                    order.OrderDate,
                    order.ProductID);
            }

            Console.Read();
        }
    }
}
