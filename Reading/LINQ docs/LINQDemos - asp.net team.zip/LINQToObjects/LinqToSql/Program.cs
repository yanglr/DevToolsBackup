﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Text;
using System.Transactions;
using Data;
using Model;

namespace LinqToSql
{
    class Program
    {
        static void Main(string[] args)
        {
            PerformCrudOperations();
            Console.Read();
        }

        static void PerformCrudOperations()
        {
            using (TransactionScope scope = new TransactionScope()) //Serializable IsolationLevel by default (highest level)
            {
                using (NorthwindDataContext context = new NorthwindDataContext())
                {
                    context.Log = Console.Out;
                    //Insert Record
                    Customer cust = new Customer();
                    cust.CustomerID = "ZZZZZ";
                    cust.Address = "1234 Anywhere St.";
                    cust.City = "Phoenix";
                    cust.CompanyName = "Interface";
                    cust.ContactName = "Johnny Coder";
                    cust.ContactTitle = "Code Jockey";
                    cust.Country = "USA";
                    cust.Fax = null;
                    cust.Phone = "602-123-1234";
                    cust.PostalCode = "85003";
                    cust.Region = null;

                    Order order = new Order();
                    order.CustomerID = cust.CustomerID;
                    order.EmployeeID = 5;
                    order.Freight = 32.00M;
                    order.OrderDate = DateTime.Now;
                    order.RequiredDate = DateTime.Now.AddDays(2);
                    order.ShipAddress = "1234 Anywhere St.";
                    order.ShipCity = "Phoenix";
                    order.ShipCountry = "USA";
                    order.ShipName = cust.ContactName;
                    order.ShippedDate = DateTime.Now.AddDays(1);
                    order.ShipPostalCode = "85003";

                    //Add Order to Customer
                    cust.Orders.Add(order);

                    context.Customers.InsertOnSubmit(cust);
                    context.SubmitChanges();
                    Console.WriteLine("Inserted new Customer Record with " + cust.Orders.Count.ToString() + " order(s).");

                    //Update customer
                    cust.ContactName = "Danny Bug Man";
                    context.SubmitChanges();

                    //Update customer created with different data context
                    Console.WriteLine("Updating Customer from different data context");

                    //Will cause error because cust2 is from different data context
                    //Easiest fix is to add TimeStamp field to table
                    try
                    {
                        Customer cust2 = GetCustomer("ALFKI");
                        cust2.ContactName = "Maria Anders2";
                        context.Customers.Attach(cust2, true);
                        context.SubmitChanges();
                    }
                    catch (Exception exp)
                    {
                        Console.WriteLine("Error: " + exp.Message + Environment.NewLine);
                    }

                    // Delete Records
                    context.Orders.DeleteOnSubmit(order);
                    context.Customers.DeleteOnSubmit(cust);
                    context.SubmitChanges();
                    Console.WriteLine("Customer deleted");
                    scope.Complete();

                } //End NorthwindDataContext
            } //End TransactionScope

        }

        //Used to get a Customer type from a different data context
        static Customer GetCustomer(string id)
        {
            //Load Customer from different data context (on purpose)
            using (NorthwindDataContext context = new NorthwindDataContext())
            {
                return context.Customers.Where(c => c.CustomerID == id).SingleOrDefault();
            }
        }
    }
}

