﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Data;
using System.Text;
using System.Globalization;

namespace LinqToDataSet
{
    public class GroupWithLet
    {
        public static void Main()
        {
            // Fill the DataSet.
            DataSet ds = new DataSet();
            ds.Locale = CultureInfo.InvariantCulture;
            DAL.FillDataSet(ds);

            DataTable orders = ds.Tables["SalesOrderHeader"];

            var query =
                from order in orders.AsEnumerable()
                group order by order.Field<Int32>("ContactID") into g
                let averageTotalDue = g.Average(order => order.Field<decimal>("TotalDue"))
                select new
                {
                    Category = g.Key,
                    CheapestProducts =
                        g.Where(order => order.Field<decimal>("TotalDue") ==
                                    averageTotalDue)
                };


            foreach (var orderGroup in query)
            {
                Console.WriteLine("ContactID: {0}", orderGroup.Category);
                foreach (var order in orderGroup.CheapestProducts)
                {
                    Console.WriteLine("Average total due for SalesOrderID {1} is: {0}",
                        order.Field<decimal>("TotalDue"),
                        order.Field<Int32>("SalesOrderID"));
                }
                Console.WriteLine("");
            }

            Console.Read();
        }
    }
}
