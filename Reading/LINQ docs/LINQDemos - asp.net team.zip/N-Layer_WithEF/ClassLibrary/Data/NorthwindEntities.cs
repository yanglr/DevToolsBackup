﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.EntityClient;
using System.Data.Objects.DataClasses;
using System.Data.Objects;
using System.Data;

namespace Data
{
    public partial class NorthwindEntities : System.Data.Objects.ObjectContext
    {
        public int ap_GetCustomerOrdersCount(string customerID)
        {
            EntityParameter param = new EntityParameter("CustomerID",DbType.String);
            param.Value = customerID;
            return (int)EFUtils.ExecuteScalar(this, "ap_GetCustomerOrdersCount", param);
        }

        public IEnumerable<string> ap_GetCountries()
        {
            EntityDataReader reader = EFUtils.ExecuteReader(this, "ap_GetCountries");
            if (reader != null && reader.HasRows)
            {
                List<string> countries = new List<string>();
                while (reader.Read())
                {
                    countries.Add(reader[0].ToString());
                }
                return countries.ToArray<string>();
            }
            return null;
        }

    }
}
