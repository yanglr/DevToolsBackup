﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.EntityClient;
using System.Data.Objects;
using System.Data.Common;
using System.Data;
using System.Data.Objects.DataClasses;

namespace Data
{
    //Written by Griff Townsend
    //http://grifftownsend.blogspot.com/2008/08/small-extension-to-entity-framework.html
    public static class EFUtils
    {
        public static object ExecuteScalar(this ObjectContext context, string functionName, params object[] parameters) 
        { 
            if (context == null) return null;
            if (context.Connection.State == ConnectionState.Closed) context.Connection.Open();
            EntityCommand command = CreateStoreCommand(context, functionName, parameters); 
            return command.ExecuteScalar(); 
        }

        public static EntityDataReader ExecuteReader(this ObjectContext context, string functionName, params object[] parameters)
        {
            if (context == null) return null;
            if (context.Connection.State == ConnectionState.Closed) context.Connection.Open();
            EntityCommand command = CreateStoreCommand(context, functionName, parameters);
            return command.ExecuteReader(CommandBehavior.SequentialAccess);
        }

        public static void AttachUpdated(this ObjectContext context, EntityObject objectDetached)
        {
            if (objectDetached.EntityState == EntityState.Detached)
            {
                object original = null;
                if (context.TryGetObjectByKey(objectDetached.EntityKey, out original))
                    context.ApplyPropertyChanges(objectDetached.EntityKey.EntitySetName, objectDetached);
                else
                    throw new ObjectNotFoundException();
            }
        }

        private static EntityCommand CreateStoreCommand(ObjectContext context, string functionName, object[] parameters)
        {
            EntityConnection entityConnection = (EntityConnection)context.Connection;
            string commandName = string.Format("{0}.{1}",
                context.DefaultContainerName, functionName);
            EntityCommand entityCommand = entityConnection.CreateCommand();
            entityCommand.CommandType = System.Data.CommandType.StoredProcedure;
            entityCommand.CommandText = commandName;
            if (parameters != null && parameters.Length > 0)
            {
                EntityParameter[] dbParams = new EntityParameter[parameters.Length];
                if (parameters is EntityParameter[])
                {
                    ((EntityParameter[])parameters).CopyTo(dbParams, 0);
                }
                else
                {
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        EntityParameter p = null; object param = parameters[i];
                        if (param is DbParameter)
                        {
                            DbParameter parm = (DbParameter)param;
                            p = (EntityParameter)parm;
                        }
                        else if (param is ObjectParameter)
                        {
                            p = entityCommand.CreateParameter();
                            ObjectParameter o = (ObjectParameter)param;
                            p.ParameterName = (o.Name.StartsWith("@")) ? o.Name.TrimStart(new char[] { '@' }) : o.Name; p.Value = o.Value;
                        }
                        else
                        {
                            p = entityCommand.CreateParameter();
                            p.Value = parameters[i];
                        }
                        dbParams[i] = p;
                    }
                }
                entityCommand.Parameters.AddRange(dbParams);
            }
            return entityCommand;
        }
    }
}
