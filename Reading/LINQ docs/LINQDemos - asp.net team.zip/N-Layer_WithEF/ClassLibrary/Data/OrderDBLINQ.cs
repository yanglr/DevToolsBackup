﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Text;
using Model;

namespace Data
{
    public class OrderDBLINQ : OrderDBBase
    {
        public override IEnumerable<Order> GetOrders(string custID)
        {
            using (NorthwindEntities context = DataContext)
            {
                IEnumerable<Order> orders = (from o in context.Orders
                                            where o.Customers.CustomerID == custID
                                            select o).ToArray<Order>();
                return orders;
            }
        }



        public override IEnumerable<OrderDescription> GetOrderDetails(int orderID)
        {

            //SQL-ish way of doing it that's a little more complex than it should be
            //IEnumerable<OrderDescription> orders =
            //    from o in context.Orders
            //    where o.OrderID == orderID
            //    join s in context.Shippers on o.ShipVia equals s.ShipperID
            //    join od in context.OrderDetails on o.OrderID equals od.OrderID
            //    join p in context.Products on od.ProductID equals p.ProductID
            //    join supplier in context.Suppliers on p.SupplierID equals supplier.SupplierID
            //    let total = od.Quantity * od.UnitPrice
            //    select new OrderDescription
            //    {
            //        Product = p.ProductName,
            //        Quantity = od.Quantity,
            //        ShipperName = s.CompanyName,
            //        Total = total,
            //        UnitPrice = od.UnitPrice,
            //        SupplierName = supplier.CompanyName
            //    };

            using (NorthwindEntities context = DataContext)
            {
                return
                  (from o in context.Orders
                   where o.OrderID == orderID
                   from od in o.Order_Details
                   let total = od.Quantity * od.UnitPrice
                   select new
                   {
                       Product = od.Products.ProductName,
                       Quantity = od.Quantity,
                       ShipperName = o.Shippers.CompanyName,
                       Total = total,
                       UnitPrice = od.UnitPrice,
                       SupplierName = od.Products.Suppliers.CompanyName
                   }).ToArray()
                   /* Following required since you can't project to an OrderDescription entity object directly above */
                   .Select(r => new OrderDescription{Product=r.Product, Quantity=r.Quantity, 
                       ShipperName=r.ShipperName, SupplierName=r.SupplierName, Total=r.Total, UnitPrice=r.UnitPrice});
            }
        }

    }
}
