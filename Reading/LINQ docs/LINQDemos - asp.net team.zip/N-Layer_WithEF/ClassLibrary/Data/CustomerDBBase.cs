﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Linq;
using System.Configuration;
using System.Web;
using Model;
using System.Data;

namespace Data
{
    public abstract class CustomerDBBase : DBBase
    {
        //Dynamically creates CustomerDB class (LINQ, Lambda or Sprocs) by reading from web.config file <appSettings>
        public static CustomerDBBase Create()
        {
            string typeString = ConfigurationManager.AppSettings["CustomerDBType"];
            Type dbType = Type.GetType(typeString);
            return (CustomerDBBase)Activator.CreateInstance(dbType);
        }

        #region Get Methods

        public abstract Customer GetCustomer(string custID);

        public abstract int GetCustomerOrdersCount(string custID);

        public abstract IEnumerable<Customer> GetCustomers();

        public abstract IEnumerable<Customer> GetCustomersByCountry(string country);

        public abstract IEnumerable<string> GetCountries();

        #endregion

        #region Update Methods

        public virtual OperationStatus UpdateCustomer(Customer cust)
        {
            NorthwindEntities context = null;
            try
            {
                context = DataContext;
                //Set entity key for Customer entity
                cust.EntityKey = new EntityKey("NorthwindEntities.Customers", "CustomerID", cust.CustomerID);
                //Call custom extension method to update operation
                context.AttachUpdated(cust);
                context.SaveChanges();
            }
            catch (Exception exp)
            {
                return new OperationStatus(false, exp.Message, exp);
            }
            finally
            {
                if (context != null) context.Dispose();
            }
            return new OperationStatus(true, null, null);
        }

        #endregion

        #region Delete Methods

        public virtual OperationStatus DeleteCustomer(Customer cust)
        {
            NorthwindEntities context = null;
            try
            {
                context = DataContext;
                context.AttachTo("NorthwindEntities.Customers", cust);
                context.DeleteObject(cust);
                context.SaveChanges();
            }
            catch (Exception exp)
            {
                return new OperationStatus(false, exp.Message, exp);
            }
            finally
            {
                if (context != null) context.Dispose();
            }
            return new OperationStatus(true, null, null);
        }

        #endregion

        #region Insert methods

        public virtual OperationStatus InsertCustomer(Customer cust)
        {
            NorthwindEntities context = null;
            try
            {
                context = DataContext;
                context.AddToCustomers(cust);
                context.SaveChanges();
            }
            catch (Exception exp)
            {
                return new OperationStatus(false, exp.Message, exp);
            }
            finally
            {
                if (context != null) context.Dispose();
            }
            return new OperationStatus(true, null, null);
        }

        #endregion
    }
}
