﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;

namespace Data
{
    public class CustomerDBLINQ : CustomerDBBase
    {

        #region Get Methods

        public override Customer GetCustomer(string custID)
        {
            using (NorthwindEntities context = DataContext)
            {
                Customer cust = (from c in context.Customers
                                 where c.CustomerID == custID
                                 select c).FirstOrDefault<Customer>();
                return cust;
            }
        }

        public override int GetCustomerOrdersCount(string custID)
        {
            using (NorthwindEntities context = DataContext)
            {

                int count = (from c in context.Orders
                             where c.Customers.CustomerID == custID
                             select c).Count();
                return count;
            }
        }

        public override IEnumerable<Customer> GetCustomers()
        {
            using (NorthwindEntities context = DataContext)
            {

                IEnumerable<Customer> custs = (from c in context.Customers
                                              select c).ToArray<Customer>();
                return custs;
            }
        }

        public override IEnumerable<Customer> GetCustomersByCountry(string country)
        {
            using (NorthwindEntities context = DataContext)
            {

                IEnumerable<Customer> custs = (from c in context.Customers
                                              where c.Country == country
                                              select c).ToArray<Customer>();
                return custs;
            }
        }

        public override IEnumerable<string> GetCountries()
        {
            using (NorthwindEntities context = DataContext)
            {
                IEnumerable<string> countries = (from c in context.Customers
                                                 select c.Country).Distinct<string>();

                return countries.ToList<string>();
            }
        }

        #endregion

    }
}
