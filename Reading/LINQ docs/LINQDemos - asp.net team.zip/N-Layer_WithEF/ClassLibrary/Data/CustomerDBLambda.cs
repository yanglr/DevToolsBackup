﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Model;

namespace Data
{
    public class CustomerDBLambda : CustomerDBBase
    {

        #region Get Methods

        public override Customer GetCustomer(string custID)
        {
            using (NorthwindEntities context = DataContext)
            {
                return context.Customers.Where(c => c.CustomerID == custID).SingleOrDefault<Customer>();
            }
        }

        public override int GetCustomerOrdersCount(string custID)
        {
            using (NorthwindEntities context = DataContext)
            {
                return context.Orders.Where(o => o.Customers.CustomerID == custID).Count();
            }
        }

        public override IEnumerable<Customer> GetCustomers()
        {
            using (NorthwindEntities context = DataContext)
            {
                return context.Customers.ToArray<Customer>();
            }
        }

        public override IEnumerable<Customer> GetCustomersByCountry(string country)
        {
            using (NorthwindEntities context = DataContext)
            {
                return (IEnumerable<Customer>)context.Customers.Where(c => c.Country == country).ToArray<Customer>();
            }
        }

        public override IEnumerable<string> GetCountries()
        {
            using (NorthwindEntities context = DataContext)
            {
                return context.Customers.Select(c => c.Country).Distinct<string>().ToArray<string>();
            }
        }

        #endregion
    }
}
