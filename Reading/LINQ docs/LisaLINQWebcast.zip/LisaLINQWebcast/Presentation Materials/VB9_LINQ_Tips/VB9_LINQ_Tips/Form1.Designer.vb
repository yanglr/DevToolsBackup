﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmResults
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblResultCount = New System.Windows.Forms.Label
        Me.GridView = New System.Windows.Forms.DataGridView
        Me.listboxObjectDisplay = New System.Windows.Forms.ListBox
        Me.txtXMLDisplay = New System.Windows.Forms.RichTextBox
        Me.lblTimeElapsedNumber = New System.Windows.Forms.Label
        Me.txtlblTimeElapsed = New System.Windows.Forms.Label
        Me.lblPrevTimeElapsedNumber = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblPrevTotalCount = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnReExecute = New System.Windows.Forms.Button
        CType(Me.GridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Total Result Count:"
        '
        'lblResultCount
        '
        Me.lblResultCount.AutoSize = True
        Me.lblResultCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResultCount.Location = New System.Drawing.Point(157, 25)
        Me.lblResultCount.Name = "lblResultCount"
        Me.lblResultCount.Size = New System.Drawing.Size(0, 20)
        Me.lblResultCount.TabIndex = 2
        Me.lblResultCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GridView
        '
        Me.GridView.AllowUserToAddRows = False
        Me.GridView.AllowUserToDeleteRows = False
        Me.GridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.GridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridView.Location = New System.Drawing.Point(16, 57)
        Me.GridView.Name = "GridView"
        Me.GridView.ReadOnly = True
        Me.GridView.Size = New System.Drawing.Size(941, 598)
        Me.GridView.TabIndex = 3
        Me.GridView.Visible = False
        '
        'listboxObjectDisplay
        '
        Me.listboxObjectDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listboxObjectDisplay.FormattingEnabled = True
        Me.listboxObjectDisplay.ItemHeight = 20
        Me.listboxObjectDisplay.Location = New System.Drawing.Point(16, 57)
        Me.listboxObjectDisplay.Name = "listboxObjectDisplay"
        Me.listboxObjectDisplay.Size = New System.Drawing.Size(941, 604)
        Me.listboxObjectDisplay.TabIndex = 4
        Me.listboxObjectDisplay.Visible = False
        '
        'txtXMLDisplay
        '
        Me.txtXMLDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXMLDisplay.Location = New System.Drawing.Point(16, 57)
        Me.txtXMLDisplay.Name = "txtXMLDisplay"
        Me.txtXMLDisplay.Size = New System.Drawing.Size(941, 599)
        Me.txtXMLDisplay.TabIndex = 5
        Me.txtXMLDisplay.Text = ""
        Me.txtXMLDisplay.Visible = False
        '
        'lblTimeElapsedNumber
        '
        Me.lblTimeElapsedNumber.AutoSize = True
        Me.lblTimeElapsedNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeElapsedNumber.Location = New System.Drawing.Point(768, 25)
        Me.lblTimeElapsedNumber.Name = "lblTimeElapsedNumber"
        Me.lblTimeElapsedNumber.Size = New System.Drawing.Size(0, 20)
        Me.lblTimeElapsedNumber.TabIndex = 7
        Me.lblTimeElapsedNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtlblTimeElapsed
        '
        Me.txtlblTimeElapsed.AutoSize = True
        Me.txtlblTimeElapsed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlblTimeElapsed.Location = New System.Drawing.Point(623, 25)
        Me.txtlblTimeElapsed.Name = "txtlblTimeElapsed"
        Me.txtlblTimeElapsed.Size = New System.Drawing.Size(144, 20)
        Me.txtlblTimeElapsed.TabIndex = 6
        Me.txtlblTimeElapsed.Text = "Time Elapsed (ms):"
        '
        'lblPrevTimeElapsedNumber
        '
        Me.lblPrevTimeElapsedNumber.AutoSize = True
        Me.lblPrevTimeElapsedNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrevTimeElapsedNumber.Location = New System.Drawing.Point(715, 677)
        Me.lblPrevTimeElapsedNumber.Name = "lblPrevTimeElapsedNumber"
        Me.lblPrevTimeElapsedNumber.Size = New System.Drawing.Size(0, 20)
        Me.lblPrevTimeElapsedNumber.TabIndex = 11
        Me.lblPrevTimeElapsedNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(570, 677)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(144, 20)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Time Elapsed (ms):"
        '
        'lblPrevTotalCount
        '
        Me.lblPrevTotalCount.AutoSize = True
        Me.lblPrevTotalCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrevTotalCount.Location = New System.Drawing.Point(430, 677)
        Me.lblPrevTotalCount.Name = "lblPrevTotalCount"
        Me.lblPrevTotalCount.Size = New System.Drawing.Size(0, 20)
        Me.lblPrevTotalCount.TabIndex = 9
        Me.lblPrevTotalCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(279, 677)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(145, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Total Result Count:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(12, 677)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(182, 20)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Previous Query Stats:"
        '
        'btnReExecute
        '
        Me.btnReExecute.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReExecute.Location = New System.Drawing.Point(866, 677)
        Me.btnReExecute.Name = "btnReExecute"
        Me.btnReExecute.Size = New System.Drawing.Size(91, 23)
        Me.btnReExecute.TabIndex = 13
        Me.btnReExecute.Text = "Re-execute"
        Me.btnReExecute.UseVisualStyleBackColor = True
        '
        'frmResults
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(969, 734)
        Me.Controls.Add(Me.btnReExecute)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblPrevTimeElapsedNumber)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblPrevTotalCount)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblTimeElapsedNumber)
        Me.Controls.Add(Me.txtlblTimeElapsed)
        Me.Controls.Add(Me.txtXMLDisplay)
        Me.Controls.Add(Me.listboxObjectDisplay)
        Me.Controls.Add(Me.GridView)
        Me.Controls.Add(Me.lblResultCount)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmResults"
        Me.Text = "Results Form"
        CType(Me.GridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblResultCount As System.Windows.Forms.Label
    Friend WithEvents GridView As System.Windows.Forms.DataGridView
    Friend WithEvents listboxObjectDisplay As System.Windows.Forms.ListBox
    Friend WithEvents txtXMLDisplay As System.Windows.Forms.RichTextBox
    Friend WithEvents lblTimeElapsedNumber As System.Windows.Forms.Label
    Friend WithEvents txtlblTimeElapsed As System.Windows.Forms.Label
    Friend WithEvents lblPrevTimeElapsedNumber As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblPrevTotalCount As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnReExecute As System.Windows.Forms.Button

End Class
