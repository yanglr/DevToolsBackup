﻿'Option Compare Text
Imports System.Data.Linq
Imports System.Collections.Generic

Public Class frmResults
    Public sw As New System.Diagnostics.Stopwatch
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        startTimer()
        'Replace the line below with the query example you want to run.
        ConstructQuery_Tip1()
        endTimer()
    End Sub

#Region "Constructing Queries: Best Practices & Gotchas"

#Region "Which operators are required in a query?"
    '[Tip #1] 'From' is the only operator required. 'Select' is not required.
    Sub ConstructQuery_Tip1()
        Dim nwDataContext As New NorthwindDataContext
        Dim query = From cust In nwDataContext.Customers _
                    Where cust.Country = "France"
        DisplayDBResults(query)
    End Sub
#End Region

#Region "How should I order my query clauses?"
    '[Tip #2] Query operators can be applied in any order.
    Sub ConstructQuery_Tip2()
        Dim nwDataContext As New NorthwindDataContext
        Dim query1 = From cust In nwDataContext.Customers _
                     Where cust.Country = "France" _
                     Order By cust.CustomerID Ascending _
                     Select cust.CustomerID, cust.ContactName, cust.Address

        Dim query2 = From cust In nwDataContext.Customers _
                     Where cust.Country = "France" _
                     Select cust.CustomerID, cust.ContactName, cust.Address _
                     Order By CustomerID Ascending

        DisplayDBResults(query2)

        '[Tip #3]: Note how control variable names differ, before or after projections.

        '[Tip #4]: Make sure to keep variables of interest in scope.
        Dim query3 = From cust In nwDataContext.Customers _
                     Select cust.Country, cust.CustomerID, cust.ContactName, cust.Address _
                     Where Country = "France" _
                     Select CustomerID, ContactName, Address _
                     Order By CustomerID Ascending
    End Sub
#End Region

#Region "When should I alias projection names?"
    ' [Tip #5] Alias projection names to keep query code consistent with
    ' naming conventions in the rest of your code (ie. PascalCasing for properties).
    ' Aliasing gives you control over these object names for later use.
    Sub ConstructQuery_Tip5()
        Dim db As New NorthwindDataContext
        ' Example1: Results by default.
        Dim customers = From cust In db.Customers _
                        Select cust.ContactName, cust.CompanyName, cust.Country, cust.CustomerID

        For Each customer In customers
            'View the intellisense member completion list here:
            'customer.
        Next

        ' Example2: Results after customization.
        Dim customers2 = From cust In db.Customers _
                         Select Name = cust.ContactName, _
                                Company = cust.CompanyName, _
                                Country = cust.Country, _
                                ID = cust.CustomerID

        For Each customer In customers2
            'View the intellisense member completion list here:
            'customer.
        Next
    End Sub
#End Region

#Region "When do I *need* to alias projection names?"
    '[Tip #6] Alias projection names when multiple default names conflict.
    Sub ConstructQuery_Tip6()
        Dim db As New NorthwindDataContext
        Dim orders = From cust In db.Customers, ord In db.Orders _
                     Where ord.ShipCountry = cust.Country _
                     Select cust.CustomerID, OrderID = ord.CustomerID

        'To Fix: Alias a name in the projection. (Start with 'OrderID =' missing...)
    End Sub
#End Region

#Region "What names should I use in my query?"
    '[Tip #6]: Use singular names for control variables and plural names for data sources 
    'or query variables.

    '[Tip #7]: Make it clear from your query variable name that the query variable is just
    ' the definition of the query. It does not always hold the results.
#End Region

#Region "What are the implications of changing my Select clause?"
    '[Tip #8]: Varying the number of columns selected will impact the resulting shape.
    Sub ConstructQuery_Tip8()
        Dim nwDataContext As New NorthwindDataContext

        'This query results in an IEnumerable(Of Customer)
        Dim query1 = From cust In nwDataContext.Customers _
                     Select cust

        'This query results in an IEnumerable(Of <anonymous type>)
        Dim query2 = From cust In nwDataContext.Customers _
                     Select cust.CustomerID, cust.ContactName, cust.Address

        '[Tip #9]: For data-binding, you will often need to select the whole column.
        '[Tip #10]: However, selecting only the columns you need (when possible) will 
        'help performance. 
    End Sub
#End Region

#Region "What if all I'm interested in is the total count?"
    '[Tip #12]: Use the Aggregate operator!
    Sub ConstructQuery_Tip12()
        Dim nwDataContext As New NorthwindDataContext
        Dim query = Aggregate cust In nwDataContext.Customers _
                    Where cust.Country = "France" _
                    Into Count()
        MsgBox("The total count is: " & query)
        DisplayDBResults(From cust In nwDataContext.Customers _
                         Where cust.Country = "France")
    End Sub
#End Region

#Region "How should I order my SQL and in-memory data sources?"
    '[Tip #13]: Make local queries the dominant data source & use them first.
    ' Unlike query operators, the order of joining data sources DOES matter.  
    ' Local queries cannot be remoted, which is what will happen if the LINQ to SQL query appears first.
    Sub ConstructQuery_Tip13()
        Dim db As New NorthwindDataContext
        Dim arr() As String = {"ALFKI", "BAZZLE"}

        'Incorrect
        Dim query1 = From cust In db.Customers _
                     From elem In arr _
                     Where elem = cust.CustomerID _
                     Select cust
        'Correct
        Dim query2 = From elem In arr _
                     From cust In db.Customers _
                     Where elem = cust.CustomerID _
                     Select cust

        DisplayDBResults(query2)
    End Sub
#End Region

#Region "What should I look out for when doing LINQ to SQL?"
    '[Tip #14] Be aware of potential discontinuities between your LINQ provider and VB.
    Sub ConstructQuery_Tip14()
        Dim srcA = New String() {"Holly", "Beth", "Megan", "Priscilla", "Helen", "Marisa"}
        Dim srcB = New String() {"beth", "Sue", "Kelly", "Helen"}

        'Run with "Option Compare Text"
        Dim names1 = From nameA In srcA, nameB In srcB _
                    Where nameA = nameB

        ''Equals' will get executed according to the DB server rules, and will not 
        'necessarily be the same as '=' in VB. In this example, 'Equals' produces a 
        'different result because it doesn't consider"Option Compare Text".
        Dim names2 = From nameA In srcA _
                     Join nameB In srcB _
                     On nameA Equals nameB

        DisplayDBResults(names2)
    End Sub
#End Region

#Region "What if, for some reason, I can't write my SQL query in VB?"
    ' [Tip #15] DON'T leave VB! ;) Use "ExecuteQuery" to run the SQL query within still using DataContext. 
    ' "ExecuteCommand" and "Translate" are also available.
    ' We don't expect this to be common, but it's nice having a "back door" just in case!
    Sub ConstructQuery_Tip15()
        Dim nwDataContext As New NorthwindDataContext

        DisplayDBResults(nwDataContext.ExecuteQuery(Of Customer) _
                         ("Select * From Customers"))
    End Sub
#End Region

#Region "Any other good advice for LINQ to SQL?"
    '[Tip #16] Use the strongly-typed DataContexts generated by the DLINQ designer.
    '[Tip #17] Use the DLINQ designer - it's a great way to get started!
    '[Tip #18] Use your DataContexts as temporary objects, to prevent stale data.
#End Region

#Region "How should I write long queries?"
    '[Tip #19] Take advantage of deferred execution to decompose queries & make them more readable.
    Sub ConstructQuery_Tip19()
        Dim db As New NorthwindDataContext

        'Better
        Dim lonCustomers = From cust In db.Customers _
                           Where cust.City = "London"

        Dim recentOrders = From ord In db.Orders _
                           Where ord.OrderDate.Value < #3/1/1999#

        Dim lonOrdInfos1 = From cust In lonCustomers _
                           Join ord In recentOrders _
                           On cust.CustomerID Equals ord.CustomerID _
                           Select ord.OrderDate, ord.ShipCity, _
                                  ord.ShippedDate

        'Worse
        Dim lonOrdInfos2 = From cust In db.Customers _
                           Join ord In db.Orders _
                           On cust.CustomerID Equals ord.CustomerID _
                           Where cust.City = "London" And _
                                 ord.OrderDate.Value < #3/1/1999# _
                           Select ord.OrderDate, ord.ShipCity, _
                                  ord.ShippedDate

        DisplayDBResults(lonOrdInfos2)

        'Note: If you can access all the order info you need from the Orders collection in your Customer object, then the best practice is actually to just bring down the Customers table and use that. 
        'This code is just used as a decomposability example, not meant to be a best practice for how to get this particular data.
    End Sub
#End Region

#End Region

#Region "Performance"
#Region "What can I do to optimize the performance of my queries?"
    '[Tip #20]: Use predicates that limit your working set earlier on. (Ex. 'Where', 'Take')
    'Use clauses that expand your working set later. (Ex. 'Join')
    ''Order By' and 'Distinct' have no such impact and typically go at the the end...
    Sub Performance_Tip20()
        Dim db As New NorthwindDataContext
        Dim customers1 = From cust In db.Customers _
                         Order By cust.CompanyName Descending _
                         Select cust.ContactName, cust.CompanyName, cust.Country _
                         Where Country = "France"

        'The above query will run much slower than the following:
        Dim customers2 = From cust In db.Customers _
                         Where cust.Country = "France" _
                         Select cust.ContactName, cust.CompanyName, cust.Country _
                         Order By CompanyName Descending
        DisplayDBResults(customers2)

        'Note: The more aggressive the filter, the bigger the impact on performance. Even 
        'if it is a weak filter though, it still never hurts to place predicates early!
    End Sub
#End Region

#Region "How can I control when the query gets executed?"
    '[Tip #21] Control deferred execution with procedures such as ToList and ToArray 
    'to force evaluation .
    Sub Performance_Tip21()
        Dim db As New NorthwindDataContext
        Dim customers2 = (From cust In db.Customers _
                         Where cust.Country = "France" _
                         Select cust.ContactName, cust.CompanyName, cust.Country _
                         Order By CompanyName Descending).ToList()
        If customers2.Count > 9 Then
            MsgBox("First Customer: " & customers2(0).ToString)
            MsgBox("Tenth Customer: " & customers2(9).ToString)
        End If
        DisplayObjects(customers2)

        '[Tip #22]: When accessing results of a query multiple times, call 'ToList' early
        'and store the data in a local variable, to avoid re-executing the query each time.
    End Sub
#End Region

    Private Shared storedQuery As System.Func(Of NorthwindDataContext, String, System.Linq.IQueryable(Of String))
#Region "What can I do to minimize database trips, when running similar queries?"
    '[Tip #23]: Use compiled queries.
    Sub Performance_Tip23()
        'Here is the query we want to execute several times:
        'Dim query = From cust In nwDataContext.Customers _
        '            Where cust.City = "London" _
        '            Select cust.CustomerID

        Dim nwDataContext As New NorthwindDataContext
        If storedQuery Is Nothing Then
            'Input to 'Compile' is a Lambda function describing the query.
            'Lambda parameters here are the NorthwindDataContext variable & city String.
            storedQuery = CompiledQuery.Compile(Function(ByVal x As NorthwindDataContext, _
                                                ByVal city As String) _
                              From cust In x.Customers _
                              Where cust.City = city _
                              Select cust.CustomerID)
        End If

        'Execute the query.
        DisplayObjects(storedQuery(nwDataContext, "London"))
    End Sub

#End Region

#End Region

#Region "Debugging"
#Region "What changes are allowed to query code while debugging?"
    '[Tip #24] Limit your debug-time changes to those AROUND the query. Other changes are Rude Edits.
    'Cannot change source, query variable name, or anything in the query. 
    'Can change code following though.
    Sub Debugging_Tip24()
        Dim cities = New String() {"Rio de Janeiro", "Seattle", "Boston", "Los Angeles", "Portland"}
        Dim nwDataContext As New NorthwindDataContext

        Dim orders = From cit In cities _
                     Join ord In nwDataContext.Orders _
                     On ord.ShipCity Equals cit _
                     Select ord.ShipCity, ord.ShipName _
                     Order By ShipCity Ascending
        Stop
        DisplayDBResults(orders)
        MsgBox(orders(1).ToString)
        Stop
        '[Tip #25]: Use the query datatip & watch visualizer instead, 
        'to get a sense of what's going on. Click to force evaluation.

        '[Tip #26]: Decomposing queries into smaller components will also help debugging.
    End Sub
#End Region

#Region "How can I get more information while debugging?"
    '[Tip #27]: Use the DataContext's Log property to view SQL statements being sent to the DB.
    Sub Debugging_Tip27()
        Dim db As New NorthwindDataContext
        db.Log = New System.IO.StringWriter()
        Dim customers = From cust In db.Customers _
                  Where cust.Country = "France" _
                  Select cust.ContactName, cust.CompanyName, cust.Country _
                  Order By CompanyName Descending

        DisplayDBResults(customers)
        MsgBox(db.Log.ToString)
    End Sub
#End Region
#End Region

#Region "Formatting"
#Region "How should I format a basic query?"
    '[Tip #28] Line up query operators to improve readability.
    Sub Formatting_Tip28a()
        Dim query1 = From proc In Process.GetProcesses _
                     Where proc.Threads.Count > 10 _
                     Order By proc.Threads.Count _
                     Select proc.ProcessName, proc.Threads.Count

        ' If you want to conserve horizontal space, the following is also acceptable. 
        Dim query2 = _
            From proc In Process.GetProcesses _
            Where proc.Threads.Count > 10 _
            Order By proc.Threads.Count _
            Select proc.ProcessName, proc.Threads.Count

        Dim query3 = _
        From proc In Process.GetProcesses _
        Where proc.Threads.Count > 10 _
        Order By proc.Threads.Count _
        Select proc.ProcessName, proc.Threads.Count

        ' Highlight lines to either Tab or Shift+Tab their indentation.
        ' Once you set the desired indentation for the first clause, 
        ' the rest of the lines will also continue using that default.
        DisplayObjects(query1)
    End Sub
#End Region

#Region "How should I format a query with multiple Select statements?"
    ' Same rules as above! Line up the query operators...
    Sub Formatting_Tip28b()
        Dim query = From proc In Process.GetProcesses _
                      Select proc.ProcessName, proc.Threads.Count _
                      Where Count > 10 _
                      Order By Count _
                      Select ProcessName
        DisplayObjects(query)
    End Sub
#End Region

#Region "How should I format a nested query?"
    ' [Tip #29]: Continue lining up query operators for optimal readability.
    ' Keep the nested query at an indentation that clearly groups itself as a component.  
    Sub Formatting_Tip29()
        Dim query1 = From proc In Process.GetProcesses _
                     Select proc.ProcessName, proc.Threads.Count _
                     Where Count > 10 _
                     Order By Count

        Dim query2 = From outerProc In (From innerProc In Process.GetProcesses _
                                        Select innerProc.ProcessName, innerProc.Threads.Count) _
                     Where outerProc.Count > 10 _
                     Order By outerProc.Count

        Dim query3 = From outerProc In _
                        (From innerProc In Process.GetProcesses _
                         Select innerProc.ProcessName, _
                         innerProc.Threads.Count) _
                     Where outerProc.Count > 10 _
                     Order By outerProc.Count

        Dim query4 = From outerProc In _
                     (From innerProc In Process.GetProcesses _
                      Select innerProc.ProcessName, _
                      innerProc.Threads.Count) _
                      Where outerProc.Count > 10 _
                      Order By outerProc.Count
    End Sub
#End Region

#Region "How should I format a long list of projections?"
    '[Tip #30]: Either keep the projection list on a single line, or line up elements along a common column.
    Sub Formatting_Tip30()
        Dim db As New NorthwindDataContext
        Dim query1 = From cust In db.Customers _
                     Select cust.ContactName, cust.CompanyName, cust.Country, cust.CustomerID

        ' Either of these work formattign options work.
        ' Note that in the example below, once you specify the indentation
        ' for the second projection, the rest follow suit.
        Dim query2 = From cust In db.Customers _
                     Select cust.ContactName, _
                            cust.CompanyName, _
                            cust.Country, _
                            cust.CustomerID
        DisplayObjects(query1)
    End Sub
#End Region

#End Region

#Region "Display Routines"
    Sub DisplayDBResults(Of t)(ByVal seq As IEnumerable(Of t))
        Me.GridView.Visible = True
        Me.GridView.ScrollBars = ScrollBars.Both
        Me.Controls.Add(GridView)
        Dim pl = New List(Of t)(seq)
        Me.GridView.DataSource = pl
        Me.lblPrevTotalCount.Text = My.Settings.prevTotal
        Me.lblResultCount.Text = pl.Count.ToString
        My.Settings.prevTotal = pl.Count
        Me.GridView.AutoResizeColumns()
    End Sub
    Sub DisplayObjects(Of t)(ByVal source As IEnumerable(Of t))
        Dim counter = 0
        Me.listboxObjectDisplay.Visible = True

        For Each item In source
            Me.listboxObjectDisplay.Items.Add(item.ToString)
            counter = counter + 1
        Next
        Me.lblPrevTotalCount.Text = My.Settings.prevTotal
        Me.lblResultCount.Text = counter.ToString
        My.Settings.prevTotal = counter.ToString
    End Sub
    Sub DisplayXML(ByVal source As XElement)
        Me.txtXMLDisplay.Visible = True
        Me.txtXMLDisplay.Text = source.ToString
    End Sub
    Sub startTimer()
        sw.Reset()
        sw.Start()
    End Sub
    Sub endTimer()
        Dim timeElapsed As Long
        Me.lblPrevTimeElapsedNumber.Text = My.Settings.prevTime
        timeElapsed = sw.ElapsedMilliseconds
        lblTimeElapsedNumber.Text = timeElapsed.ToString()
        My.Settings.prevTime = timeElapsed.ToString()
    End Sub
    'For Perf Tip #23.
    Private Sub ReExecuteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReExecute.Click
        Me.listboxObjectDisplay.Items.Clear()
        startTimer()
        Performance_Tip23()
        endTimer()
    End Sub
#End Region

End Class
