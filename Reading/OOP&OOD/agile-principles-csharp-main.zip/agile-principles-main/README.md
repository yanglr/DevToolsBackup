# Introduction

This repository contains code in *Agile Principles, Patterns, and Practices in C#* with a few improvements.

## Quick start

1. Make sure you have .NET 7.0 or above installed.
2. Run `dotnet run` in the terminal.
