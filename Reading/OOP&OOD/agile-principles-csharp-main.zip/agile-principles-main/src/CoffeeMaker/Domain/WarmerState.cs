﻿namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum WarmerState {
    On,
    Off
}
