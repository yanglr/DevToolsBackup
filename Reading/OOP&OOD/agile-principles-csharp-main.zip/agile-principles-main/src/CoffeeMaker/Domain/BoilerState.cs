﻿namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum BoilerState {
    On,
    Off
}
