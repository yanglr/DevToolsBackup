namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum ReliefValveState {
    Open,
    Closed
}
