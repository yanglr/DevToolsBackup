﻿namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum WarmerPlateStatus {
    WarmerEmpty,
    PotEmpty,
    PotNotEmpty
}
