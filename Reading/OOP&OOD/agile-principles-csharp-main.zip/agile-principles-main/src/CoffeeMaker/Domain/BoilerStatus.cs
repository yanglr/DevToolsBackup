﻿namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum BoilerStatus {
    Empty,
    NotEmpty
}
