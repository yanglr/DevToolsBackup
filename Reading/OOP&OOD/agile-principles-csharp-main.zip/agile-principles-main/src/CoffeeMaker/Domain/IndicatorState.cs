﻿namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum IndicatorState {
    On,
    Off
}
