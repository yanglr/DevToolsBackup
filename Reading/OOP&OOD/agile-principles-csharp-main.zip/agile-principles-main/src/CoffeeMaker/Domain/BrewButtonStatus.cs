﻿namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public enum BrewButtonStatus {
    Pushed,
    NotPushed
}
