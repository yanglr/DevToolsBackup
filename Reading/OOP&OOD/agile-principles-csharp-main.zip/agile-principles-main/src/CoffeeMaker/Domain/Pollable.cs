namespace AgileSoftwareDevelopment.CoffeeMaker.Domain;

public interface Pollable {
    void Poll();
}
