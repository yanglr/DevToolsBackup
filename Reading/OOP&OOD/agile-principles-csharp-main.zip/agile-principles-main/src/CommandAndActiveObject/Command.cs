namespace AgileSoftwareDevelopment.CommandAndActiveObject;

public interface Command {
    void Execute();
}
