﻿namespace AgileSoftwareDevelopment.DIP;

public interface Heater {
    void Engage();
    void Disengage();
}
