﻿namespace AgileSoftwareDevelopment.DIP;

public interface Thermometer {
    double Read();
}
