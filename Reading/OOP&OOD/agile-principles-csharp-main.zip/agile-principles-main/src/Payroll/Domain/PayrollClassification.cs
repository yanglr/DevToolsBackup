﻿namespace AgileSoftwareDevelopment.Payroll.Domain {
    public interface PayrollClassification {
        double CalculatePay(Paycheck paycheck);
    }
}
