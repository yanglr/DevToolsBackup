﻿namespace AgileSoftwareDevelopment.Payroll.Domain {
    public interface Transaction {
        void Execute();
    }
}
