﻿using AgileSoftwareDevelopment.Payroll.Domain;

namespace AgileSoftwareDevelopment.Payroll.Methods {
    public class HoldMethod : PayrollMethod {
        public void Pay(Paycheck paycheck) {
            // TODO:
        }
    }
}
