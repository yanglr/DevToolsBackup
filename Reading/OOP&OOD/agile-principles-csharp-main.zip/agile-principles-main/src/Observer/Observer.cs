﻿namespace AgileSoftwareDevelopment.Observer {
    public interface Observer {
        void Update();
    }
}
