namespace AgileSoftwareDevelopment.Composite;

public interface Shape {
    void Draw();
}
