﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using SolidBlog.Code;
using SolidBlog.Models;

namespace SolidBlog.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        private IPostRepository _postRepository;

        public HomeController()
            : this(new SqlPostRepository())
        {

        }

        public HomeController(IPostRepository postRepository)
        {
            _postRepository = postRepository;
        }
        public ActionResult Index()
        {
            // dependency
            //var db = new BlogDataContext();
            //List<Post> posts = Enumerable.OrderByDescending(db.Posts, o => o.DatePosted).Take(20).ToList();

            var posts = _postRepository.List();
            return View(posts);
        }


        #region Constructor

        //private readonly IPostRepository _postRepository;

        //public HomeController()
        //    : this(new SqlPostRepository())
        //{
        //}

        //public HomeController(IPostRepository postRepository)
        //{
        //    _postRepository = postRepository;
        //}

        #endregion

        #region Index()
        //public ActionResult Index()
        //{
        //    IEnumerable<Post> posts = _postRepository.List();
        //    return View(posts);
        //}
        #endregion        
        
        public ActionResult About()
        {
            ViewData["Title"] = "About Page";
            return View();
        }

    }
}