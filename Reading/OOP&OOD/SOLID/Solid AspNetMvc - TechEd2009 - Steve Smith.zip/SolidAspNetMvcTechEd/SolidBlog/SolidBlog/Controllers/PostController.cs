﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web.Mvc;
using SolidBlog.Code;
using SolidBlog.Models;

namespace SolidBlog.Controllers
{
    public class PostController : Controller
    {
        private readonly IPostValidator postValidator;
        private readonly IPostFormatter postFormatter;
        private readonly IPostRepository postRepository;
        private readonly IPostNotificationService postNotificationService;
        private readonly ICalendar calendar;

        #region Other Actions
        public ActionResult Index()
        {
            // Add action logic here
            throw new NotImplementedException();
        }

        public ActionResult Details(int year, int month, int day, string friendlyTitle)
        {
            // dependency!
            var db = new BlogDataContext();

            var post = Enumerable.Single(db.Posts, p => p.EncodedTitle == friendlyTitle
                && p.DatePosted.Year == year
                && p.DatePosted.Month == month
                && p.DatePosted.Day == day);

            #region DI

            //Post post = _postRepository.Get(year, month, day, friendlyTitle);

            #endregion

            return View(post);
        }

        [Authorize]
        public ActionResult Create()
        {
            return View();
        }
        #endregion

        [Authorize]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(Post newPost)
        {
            // This method violates SRP, OCP, LSP, and DIP (it could violate ISP but no interfaces are used)
            if (!IsPostValid(newPost))
            {
                return View(newPost);
            }

            newPost.DatePosted = calendar.Now();

            newPost = postFormatter.FormatPost(newPost);

            postRepository.Create(newPost);

            postNotificationService.NotifySubscribers(newPost);
            return RedirectToAction("Index", "Home");
        }

        #region Helper Methods
        private List<Subscriber> GetSubscribers()
        {
            var emailSubscriber = new Subscriber() { Name = "Steve Smith", Email = "ssmith@nimblepros.com" };
            var twitterSubscriber = new TwitterSubscriber() { Name = "Steve", TwitterAlias = "ardalis" };
            var myList = new List<Subscriber>() { emailSubscriber };

            myList.Add(twitterSubscriber);

            return myList;
        }

        private bool IsPostValid(Post post)
        {
            var errors = postValidator.ValidatePost(post);
            foreach (var error in errors.Keys)
            {
                ModelState.AddModelError(error, errors[error]);
            }
            if (errors.Count > 0)
            {
                return false;
            }
            return true;
        }
        #endregion

        #region Constructor
        public PostController()
            //: this(new PostValidator(), new NewYearGreetingFormatter(), new SqlPostRepository(), new EmailPostNotificationService(), new NewYearGreetingCalendar())
        {
        }

        public PostController(
            IPostValidator postValidator,
            IPostFormatter postFormatter,
            IPostRepository postRepository,
            IPostNotificationService postNotificationService,
            ICalendar calendar)
        {
            this.postValidator = postValidator;
            this.postFormatter = postFormatter;
            this.postRepository = postRepository;
            this.postNotificationService = postNotificationService;
            this.calendar = calendar;
        }
        #endregion

        #region Refactored Create()
        // SRP - Simply responsible for creating post
        // OCP - All collaborators are injected
        // LSP - Does not change base behavior unexpectedly
        // ISP - Interfaces are small and well-factored
        // DIP - All dependencies are controlled by calling code
        [Authorize]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create2(Post newPost)
        {
            if (!IsPostValid(newPost))
            {
                return View(newPost);
            }
            newPost.DatePosted = calendar.Now();
            newPost = postFormatter.FormatPost(newPost);

            postRepository.Create(newPost);

            postNotificationService.NotifySubscribers(newPost);
            return RedirectToAction("Index", "Home");
        }
        #endregion
    }

    public class NewYearGreetingCalendar : ICalendar
    {

        #region ICalendar Members

        public DateTime Now()
        {
            return new DateTime(2010, 1, 1);
        }

        #endregion
    }

    public class NewYearGreetingFormatter : IPostFormatter
    {
        #region IPostFormatter Members

        public Post FormatPost(Post post)
        {
            if (post.DatePosted.Month == 1 &&
                post.DatePosted.Day == 1)
            {
                post.Title = "Happy New Year! " + post.Title;
            }
            post.EncodedTitle = Utility.BuildFriendlyUrl(post.Title);
            post.Abstract = Utility.GetAbstract(post.Contents);

            return post;
        }

        #endregion
    }




    // ISP violating interface
    public interface ICreateNewPost
    {
        DateTime PostCreatedTime { get; }
        void ValidatePost(Post post);
        void CreatePost(Post post);
        List<Subscriber> ListSubscribers();
        void NotifySubscribers(List<Subscriber> subscribers);
    }



    public interface IUpdatePost
    {
        DateTime PostUpdatedTime { get; }
        void ValidatePost(Post post);
        void UpdatePost(Post post);
        //List<Subscriber> ListSubscribers();
        //void NotifySubscribers(List<Subscriber> subscribers);
    }














    // alternate factoring of interfaces following ISP
    public interface IPostNotificationService
    {
        void NotifySubscribers(Post post);
    }

    public interface IPostValidator
    {
        Dictionary<string, string> ValidatePost(Post post);
    }

    public interface IPostFormatter
    {
        Post FormatPost(Post post);
    }

    public interface IPostRepository
    {
        Post Get(int year, int month, int day, string friendlyTitle);
        IEnumerable<Post> List();
        void Create(Post post);
    }

    public interface ICalendar
    {
        DateTime Now();
    }

    public class PostValidator : IPostValidator
    {
        public Dictionary<string, string> ValidatePost(Post post)
        {
            var modelErrors = new Dictionary<string, string>();
            if (String.IsNullOrEmpty(post.Title))
            {
                modelErrors.Add("title", "Title is required");
            }
            return modelErrors;
        }
    }

    public class PostFormatter : IPostFormatter
    {
        public Post FormatPost(Post post)
        {
            if (post.DatePosted.Day % 2 != 0)
            {
                post.Title = post.Title.ToUpper();
            }
            post.EncodedTitle = Utility.BuildFriendlyUrl(post.Title);
            post.Abstract = Utility.GetAbstract(post.Contents);
            return post;
        }
    }

    public class EmailPostNotificationService : IPostNotificationService
    {
        private List<Subscriber> GetSubscribers()
        {
            var emailSubscriber = new Subscriber() { Name = "Steve Smith", Email = "ssmith@nimblepros.com" };
            var myList = new List<Subscriber>() { emailSubscriber };
            return myList;
        }

        public void NotifySubscribers(Post post)
        {
            var subscribers = GetSubscribers();
            foreach (var subscriber in subscribers)
            {
                // send email
                Debug.Print("Email Sent to " + subscriber.Email + " for Post: " + post.Title);
            }
        }
    }
}