﻿using System;
using SolidBlog.Controllers;

namespace SolidBlog.Code
{
    public class NewYearCalendar : ICalendar
    {
        public DateTime Now()
        {
            return new DateTime(2010, 1, 1);
        }
    }
}
