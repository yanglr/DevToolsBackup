using System;
using SolidBlog.Controllers;

namespace SolidBlog.Models
{
    public class SystemCalendar : ICalendar
    {
        public DateTime Now()
        {
            return DateTime.Now;
        }
    }
}