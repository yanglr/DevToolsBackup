﻿using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Code
{
    public class NullPostFormatter : IPostFormatter
    {
        public Post FormatPost(Post post)
        {
            return post;
        }
    }
}
