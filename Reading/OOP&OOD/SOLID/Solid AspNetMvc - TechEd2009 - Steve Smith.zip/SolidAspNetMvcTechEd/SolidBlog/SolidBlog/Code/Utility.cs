﻿using System;
using System.Text.RegularExpressions;

namespace SolidBlog.Code
{

    public class Utility
    {
        
        public static string GetAbstract(string Text)
        {
            return GetAbstract(Text, 80);
        }

        public static string GetAbstract(string Text, int MaximumNumberOfWords)
        {
            Text = Text.Replace("&nbsp;", " ");
            Regex reg = new Regex("<.*?>", RegexOptions.Compiled);
            string stripDesc = reg.Replace(Text, String.Empty);

            string[] Words = stripDesc.Split(' ');

            if (Words.Length > MaximumNumberOfWords)
            {
                string newString = "";

                //Reset Maximum if necessary
                if (MaximumNumberOfWords < 8)
                {
                    MaximumNumberOfWords = 10;
                }

                for (int x = 0; x <= MaximumNumberOfWords - 6; x++) {
                    newString = newString + Words[x] + " ";
                }

                return newString + "...";
            }
            else
            {
                return stripDesc.Trim();
            }
        }


        public static string BuildFriendlyUrl(string value)
        {
            return Regex.Replace(value, "[^a-zA-Z0-9\\s]", "").Replace(" ", "-");
        }

    }

}