﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Code
{
    public class SqlPostRepository : IPostRepository
    {
        #region IPostRepository Members

        public SolidBlog.Models.Post Get(int year, int month, int day, string friendlyTitle)
        {
            var db = new BlogDataContext();

            var post = db.Posts.Single(p => p.EncodedTitle == friendlyTitle
                && p.DatePosted.Year == year
                && p.DatePosted.Month == month
                && p.DatePosted.Day == day);
            return post;
        }


        public IEnumerable<Post> List()
        {
            var db = new BlogDataContext();
            return db.Posts.OrderByDescending(o => o.DatePosted).Take(20).ToList();
        }



        public void Create(Post post)
        {
            var db = new BlogDataContext();
            db.Posts.InsertOnSubmit(post);
            db.SubmitChanges();
        }

        #endregion
    }
}
