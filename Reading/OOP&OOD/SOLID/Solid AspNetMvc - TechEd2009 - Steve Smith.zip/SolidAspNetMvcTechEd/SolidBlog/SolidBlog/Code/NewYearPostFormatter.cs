﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Code
{
    public class NewYearPostFormatter : IPostFormatter
    {
        public Post FormatPost(Post post)
        {
            if (post.DatePosted.Month == 1 &&
                post.DatePosted.Day == 1)
            {
                post.Title = "Happy New Year! " + post.Title;
                post.EncodedTitle = Utility.BuildFriendlyUrl(post.Title);
                post.Abstract = Utility.GetAbstract(post.Contents);
            }
            return post;
        }
    }
}
