﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Runtime.CompilerServices;

namespace SolidBlog.Helpers
{
    public static class BlogExtensions
    {
        public static string IndividualPostLink(this System.Web.Mvc.HtmlHelper helper, string text, DateTime datePosted, string friendlyTitle)
        {
            return string.Format("<a href='../../posts/{0:0000}/{1:00}/{2:00}/{3}'>{4}</a>", datePosted.Year,
                                 datePosted.Month, datePosted.Day, friendlyTitle, text);
        }
    }
}
