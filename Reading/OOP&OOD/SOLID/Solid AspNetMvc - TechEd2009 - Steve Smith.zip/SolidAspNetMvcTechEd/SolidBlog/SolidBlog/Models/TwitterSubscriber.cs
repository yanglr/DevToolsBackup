using System;

namespace SolidBlog.Models
{
    public class TwitterSubscriber : Subscriber
    {
        public string TwitterAlias { get; set; }
        public override string Email
        {
            get
            {
                throw new NotImplementedException();  // LSP violation!
            }
        }
    }
}