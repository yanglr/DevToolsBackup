namespace SolidBlog.Models
{
    public class Notifier 
    {
        public void Notify(Subscriber subscriber)
        {
            if(subscriber is TwitterSubscriber) // code smell - LSP Violation
            {
                // send direct message via Twitter
                return;
            }
            // send Email
        }
    }
}