﻿namespace SolidBlog.Models
{
    public class Subscriber
    {
        public string Name { get; set; }
        public virtual string Email { get; set; }
        public string NotificationAddress { get; set; }
    }
}
