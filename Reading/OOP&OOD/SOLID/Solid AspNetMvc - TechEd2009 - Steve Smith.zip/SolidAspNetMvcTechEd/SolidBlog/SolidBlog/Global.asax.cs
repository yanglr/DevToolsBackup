﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using MvcContrib.ControllerFactories;
using MvcContrib.Services;
using MvcContrib.StructureMap;
using SolidBlog.Code;
using SolidBlog.Controllers;
using StructureMap;
using SolidBlog.Models;

namespace SolidBlog
{
    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.IgnoreRoute("{*favicon}", new { favicon = @"(.*/)?favicon.ico(/.*)?" });

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            ConfigureIoC();
            RegisterRoutes(RouteTable.Routes);
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Debug.Print(Server.GetLastError().ToString());
        }

        private void ConfigureIoC()
        {
            StructureMapConfiguration.UseDefaultStructureMapConfigFile = false;
            StructureMapConfiguration.BuildInstancesOf<HomeController>().TheDefaultIsConcreteType<HomeController>();

            StructureMapConfiguration.BuildInstancesOf<IPostValidator>().TheDefaultIsConcreteType
                <PostValidator>();
            StructureMapConfiguration.BuildInstancesOf<IPostFormatter>().TheDefaultIsConcreteType
                <PostFormatter>();
            StructureMapConfiguration.BuildInstancesOf<IPostRepository>().TheDefaultIsConcreteType
                <SqlPostRepository>();
            StructureMapConfiguration.BuildInstancesOf<IPostNotificationService>().TheDefaultIsConcreteType
                <EmailPostNotificationService>();
            StructureMapConfiguration.BuildInstancesOf<ICalendar>().TheDefaultIsConcreteType
                <SystemCalendar>();
            
            
            DependencyResolver.InitializeWith(new StructureMapDependencyResolver());
            ControllerBuilder.Current.SetControllerFactory(typeof(IoCControllerFactory));
        }

    }
}