﻿using System.Collections.Generic;
using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Tests.Fakes
{
    public class FakePostValidator : IPostValidator
    {
        public Dictionary<string, string> ValidatePost(Post post)
        {
            return new Dictionary<string, string>();
        }
    }
}
