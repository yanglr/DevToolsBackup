﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolidBlog.Code;
using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Tests.Fakes
{
    public class FakePostRepository : IPostRepository
    {
        public Post LastPostCreated { get; set; }

        public Post Get(int year, int month, int day, string friendlyTitle)
        {
            if (friendlyTitle == "foo")
            {
                var post = new Post();
                post.DatePosted = new DateTime(year, month, day);
                post.Title = friendlyTitle;
                post.EncodedTitle = Utility.BuildFriendlyUrl(friendlyTitle);
                return post;
            }
            return null;
        }

        public IEnumerable<Post> List()
        {
            var post = Get(2009, 4, 8, "foo");
            var myList = new List<Post> { post };
            return myList;
        }

        public void Create(Post post)
        {
            LastPostCreated = post;
        }
    }

}
