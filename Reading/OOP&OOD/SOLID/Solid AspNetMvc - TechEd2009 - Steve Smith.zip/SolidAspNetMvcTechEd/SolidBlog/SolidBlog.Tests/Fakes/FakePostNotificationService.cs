﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Tests.Fakes
{
    class FakePostNotificationService : IPostNotificationService
    {
        public void NotifySubscribers(Post post)
        {
        }
    }
}
