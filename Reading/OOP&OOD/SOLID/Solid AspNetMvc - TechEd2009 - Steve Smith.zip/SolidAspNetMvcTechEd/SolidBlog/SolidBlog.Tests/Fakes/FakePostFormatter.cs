﻿using SolidBlog.Controllers;
using SolidBlog.Models;

namespace SolidBlog.Tests.Fakes
{
    public class FakePostFormatter : IPostFormatter
    {
        public Post FormatPost(Post post)
        {
            return post;
        }
    }
}
