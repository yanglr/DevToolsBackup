using System;
using SolidBlog.Controllers;

namespace SolidBlog.Tests.Fakes
{
    public class FakeCalendar : ICalendar
    {
        public DateTime CurrentTime { get; set; }
        public DateTime Now()
        {
            return CurrentTime;
        }
    }
}