﻿using System;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SolidBlog.Code;
using SolidBlog.Controllers;
using SolidBlog.Models;
using SolidBlog.Tests.Fakes;

namespace SolidBlog.Tests.Controllers
{
    [TestClass]
    public class PostControllerTester
    {
        [TestMethod]
        [ExpectedException(typeof (NotImplementedException))]
        public void Index_Should_Return_NotImplemented_Exception()
        {
            var myPostController = new PostController();
            ActionResult result = myPostController.Index();
            Assert.Fail("Index did not throw an exception.");
        }

        [TestMethod]
        public void Create_Returns_Null_For_Anonymous_User()
        {
            var myPostController = new PostController();
            var result = (ViewResult) myPostController.Create();
            Assert.IsNull(result.View);
        }

        [TestMethod]
        public void Create_Makes_Title_All_Caps_On_Odd_Days()
        {
            var testTitle = "This title is not all upper case";
            var myCalendar = new FakeCalendar();
            myCalendar.CurrentTime = new DateTime(2009, 4, 1);
            var myRepository = new FakePostRepository();
            var myPostController = new PostController(
                new FakePostValidator(),
                new PostFormatter(),
                myRepository,
                new FakePostNotificationService(),
                myCalendar);
            Post p = new Post();
            p.Title = testTitle;
            p.Contents = "bar";
            var result = (RedirectToRouteResult)myPostController.Create(p);

            var myPost = myRepository.LastPostCreated;
            Assert.AreEqual(testTitle.ToUpper(), myPost.Title);
        }

        [TestMethod]
        public void Create_Leaves_Title_Alone_On_Even_Days()
        {
            var testTitle = "This title is not all upper case";
            var myCalendar = new FakeCalendar();
            myCalendar.CurrentTime = new DateTime(2009, 4, 2);
            var myRepository = new FakePostRepository();
            var myPostController = new PostController(
                new FakePostValidator(),
                new PostFormatter(),
                myRepository,
                new FakePostNotificationService(),
                myCalendar);
            Post p = new Post();
            p.Title = testTitle;
            p.Contents = "bar";
            var result = (RedirectToRouteResult)myPostController.Create(p);

            var myPost = myRepository.LastPostCreated;
            Assert.AreEqual(testTitle, myPost.Title);
        }
    }
}