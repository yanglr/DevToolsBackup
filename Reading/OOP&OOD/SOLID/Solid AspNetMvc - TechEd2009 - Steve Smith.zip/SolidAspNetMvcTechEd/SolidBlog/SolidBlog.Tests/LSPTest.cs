﻿using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SolidBlog.Tests
{
    [TestClass]
    public class LSPTest
    {
        public class Rectangle
        {
            public virtual int Height { get; set; }
            public virtual int Width { get; set; }

            public bool IsSquare()
            {
                return Height == Width;
            }
        }

        public class Square : Rectangle
        {
            private int _width;
            public override int Width
            {
                get
                {
                    return _width;
                }
                set
                {
                    _width = value;
                    _height = value;
                }
            }
            private int _height;
            public override int Height
            {
                get
                {
                    return _height;
                }
                set
                {
                    _width = value;
                    _height = value;
                }
            }
        }


        [TestMethod]
        public void CalculateArea()
        {
            var myRectangle = new Rectangle() {Height = 2, Width = 3};
            Assert.AreEqual(6, CalcArea(myRectangle));

            // TODO: Test with a square
            myRectangle = new Square();
            myRectangle.Height = 3;
            myRectangle.Width = 2;
            Assert.AreEqual(6, CalcArea(myRectangle));


        }

        public static int CalcArea(Rectangle r)
        {
            return r.Height*r.Width;
        }





        //[TestMethod]
        //public void CalculateArea()
        //{
        //    var myRectangle = new Rectangle() { Height = 2, Width = 3 };
        //    Assert.AreEqual(6, CalcArea(myRectangle));

        //    myRectangle = new Square();
        //    myRectangle.Height = 3;
        //    myRectangle.Width = 2;
        //    Assert.AreEqual(6, CalcArea(myRectangle));

        //}

    }
}
