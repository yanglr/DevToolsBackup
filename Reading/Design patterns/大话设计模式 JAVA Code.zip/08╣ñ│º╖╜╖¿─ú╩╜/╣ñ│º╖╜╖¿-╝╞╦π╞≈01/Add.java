package code.chapter8.calculator1;

public class Add extends Operation {

    public double getResult(double numberA, double numberB){
        return numberA + numberB;
    }
    
}
