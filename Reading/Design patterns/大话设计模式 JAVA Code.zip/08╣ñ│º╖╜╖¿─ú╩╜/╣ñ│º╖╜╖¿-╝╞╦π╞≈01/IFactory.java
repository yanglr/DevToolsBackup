package code.chapter8.calculator1;

public interface IFactory {

    public Operation createOperation();
    
}
