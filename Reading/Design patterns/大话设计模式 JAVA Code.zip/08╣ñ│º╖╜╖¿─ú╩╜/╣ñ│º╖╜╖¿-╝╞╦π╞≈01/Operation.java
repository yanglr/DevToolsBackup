package code.chapter8.calculator1;

public abstract class Operation {

    public double getResult(double numberA, double numberB){
        return 0d;
    }
    
}
