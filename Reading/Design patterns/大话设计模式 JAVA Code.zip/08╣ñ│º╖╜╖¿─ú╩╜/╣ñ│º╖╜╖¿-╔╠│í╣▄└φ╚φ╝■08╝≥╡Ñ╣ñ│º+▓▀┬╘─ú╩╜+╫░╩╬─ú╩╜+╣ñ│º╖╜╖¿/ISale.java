package code.chapter8.factorymethod1;

public interface ISale {

   public double acceptCash(double price,int num);

}



