package code.chapter8.factorymethod1;

public interface IFactory {

   public ISale createSalesModel(); //创建销售模式

}



