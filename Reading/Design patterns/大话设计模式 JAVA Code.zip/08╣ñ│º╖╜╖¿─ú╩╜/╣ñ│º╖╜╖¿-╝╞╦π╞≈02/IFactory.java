package code.chapter8.calculator2;

public interface IFactory {

    public Operation createOperation(String operType);
    
}
