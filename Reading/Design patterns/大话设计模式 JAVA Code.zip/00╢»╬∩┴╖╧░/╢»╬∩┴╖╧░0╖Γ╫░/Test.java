package code.chapter0.animal0;

public class Test {

	public static void main(String[] args){

		System.out.println("**********************************************");		
		System.out.println("《大话设计模式》代码样例");
		System.out.println();		

		//System.out.println("喵");

		System.out.println();	

		// Cat cat = new Cat("咪咪");
		// cat.setShoutNum(5);
		// System.out.println(cat.shout());

		Dog dog = new Dog("旺财");
		dog.setShoutNum(8);
		System.out.println(dog.shout());

		System.out.println();		

		System.out.println("**********************************************");

	}
}
