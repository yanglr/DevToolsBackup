package code.chapter0.animal5;

public interface IChange {

	public String changeThing(String thing);

}
