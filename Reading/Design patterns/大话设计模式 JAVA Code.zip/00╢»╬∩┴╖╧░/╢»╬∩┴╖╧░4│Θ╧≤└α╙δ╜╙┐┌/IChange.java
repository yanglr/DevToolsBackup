package code.chapter0.animal4;

//声明一个IChange接口
public interface IChange {

	//此接口有一个方法ChangeThing，
	//参数是一个字符串变量，返回一字符
	public String changeThing(String thing);

}