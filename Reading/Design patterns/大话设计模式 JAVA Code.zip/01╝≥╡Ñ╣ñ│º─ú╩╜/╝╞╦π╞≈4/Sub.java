package code.chapter1.calculator4;

public class Sub extends Operation {
    public double getResult(double numberA, double numberB){
        return numberA - numberB;
    }
}
