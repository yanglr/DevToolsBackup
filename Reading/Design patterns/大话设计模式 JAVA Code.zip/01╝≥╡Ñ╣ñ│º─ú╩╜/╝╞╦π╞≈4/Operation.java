package code.chapter1.calculator4;

public abstract class Operation {

    public double getResult(double numberA, double numberB){
        return 0d;
    }
    
}
