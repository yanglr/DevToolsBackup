package code.chapter15.abstractfactory5;

//用户类接口
public interface IUser {

    public void insert(User user);

    public User getUser(int id);
}
