package code.chapter15.abstractfactory7;

public interface IFactory {

   public ISale createSalesModel(); //创建销售模式

}



