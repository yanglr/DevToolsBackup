package code.chapter15.abstractfactory7;

public interface ISale {

   public double acceptCash(double price,int num);

}



