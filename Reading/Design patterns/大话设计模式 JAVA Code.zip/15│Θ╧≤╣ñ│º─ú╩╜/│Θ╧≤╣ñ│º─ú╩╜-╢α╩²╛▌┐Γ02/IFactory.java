package code.chapter15.abstractfactory2;

//工厂接口
public interface IFactory {

    public IUser createUser();
    
}

