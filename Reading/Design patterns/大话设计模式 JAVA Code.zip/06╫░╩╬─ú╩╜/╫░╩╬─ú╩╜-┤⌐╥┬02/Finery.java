package code.chapter6.decorator2;

public abstract class Finery {

    public abstract void show();

}



