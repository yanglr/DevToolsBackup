package code.chapter6.decorator2;

public class TShirts extends Finery {

    public void show(){
        System.out.print(" 大T恤");
    }

}



