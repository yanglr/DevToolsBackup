package code.chapter6.decorator2;

public class LeatherShoes extends Finery {

    public void show(){
        System.out.print(" 皮鞋");
    }

}



