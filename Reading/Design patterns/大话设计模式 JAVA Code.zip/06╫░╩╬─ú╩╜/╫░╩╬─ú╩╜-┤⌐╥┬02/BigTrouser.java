package code.chapter6.decorator2;

public class BigTrouser extends Finery {

    public void show(){
        System.out.print(" 垮裤");
    }

}



