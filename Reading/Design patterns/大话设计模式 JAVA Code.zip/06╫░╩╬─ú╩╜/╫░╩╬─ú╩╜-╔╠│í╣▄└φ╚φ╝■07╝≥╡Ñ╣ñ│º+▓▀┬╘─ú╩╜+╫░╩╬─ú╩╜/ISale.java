package code.chapter6.decorator5;

public interface ISale {

   public double acceptCash(double price,int num);

}



