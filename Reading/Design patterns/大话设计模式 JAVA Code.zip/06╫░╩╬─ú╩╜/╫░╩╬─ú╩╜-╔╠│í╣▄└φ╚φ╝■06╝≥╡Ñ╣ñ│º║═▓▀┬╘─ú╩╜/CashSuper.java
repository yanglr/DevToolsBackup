package code.chapter6.decorator4;

public abstract class CashSuper {

    public abstract double acceptCash(double price,int num);
    
}
