package code.chapter6.decorator3;

public class Sneakers extends Finery {

    public void show(){
        System.out.print(" 球鞋");
        super.show();
    }

}



