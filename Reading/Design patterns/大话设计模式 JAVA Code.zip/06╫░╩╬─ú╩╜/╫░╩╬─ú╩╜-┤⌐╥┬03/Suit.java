package code.chapter6.decorator3;

public class Suit extends Finery {

    public void show(){
        System.out.print(" 西装");
        super.show();
    }

}



