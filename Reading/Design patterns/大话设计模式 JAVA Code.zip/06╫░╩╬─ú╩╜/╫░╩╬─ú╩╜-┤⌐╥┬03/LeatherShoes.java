package code.chapter6.decorator3;

public class LeatherShoes extends Finery {

    public void show(){
        System.out.print(" 皮鞋");
        super.show();
    }

}



