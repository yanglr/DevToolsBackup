package code.chapter6.decorator3;

public class Strawhat extends Finery {

    public void show(){
        System.out.print(" 草帽");
        super.show();
    }

}



