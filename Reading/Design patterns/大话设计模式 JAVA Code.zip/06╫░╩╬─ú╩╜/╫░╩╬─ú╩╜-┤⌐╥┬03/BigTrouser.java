package code.chapter6.decorator3;

public class BigTrouser extends Finery {

    public void show(){
        System.out.print(" 垮裤");
        super.show();
    }

}



