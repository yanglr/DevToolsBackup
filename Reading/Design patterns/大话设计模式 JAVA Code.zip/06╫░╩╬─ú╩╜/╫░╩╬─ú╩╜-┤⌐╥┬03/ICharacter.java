package code.chapter6.decorator3;

//人物形象接口
public interface ICharacter {

   public void show();

}



