package code.chapter2.strategy3;

public abstract class CashSuper {

    public abstract double acceptCash(double price,int num);
    
}
