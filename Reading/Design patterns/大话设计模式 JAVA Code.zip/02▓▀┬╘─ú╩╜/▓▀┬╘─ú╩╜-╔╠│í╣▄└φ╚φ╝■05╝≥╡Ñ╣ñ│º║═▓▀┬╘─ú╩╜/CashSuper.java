package code.chapter2.strategy5;

public abstract class CashSuper {

    public abstract double acceptCash(double price,int num);
    
}
