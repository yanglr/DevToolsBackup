using System;

namespace HeadFirstDesignPatterns.AbstractFactory.PizzaStore
{
	/// <summary>
	/// Summary description for IDough.
	/// </summary>
	public interface IDough 
	{
		string toString();
	}
}
