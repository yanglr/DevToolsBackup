﻿// Default code generation is disabled for model 'C:\Users\Jacob\Documents\_Projects\DoFramework 4.5\Upgrade 4.0 to 4.5\Patterns in Action 4.5\DataObjects\EntityFramework\Action.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.