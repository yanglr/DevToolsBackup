﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mvc.Tests.Controllers
{
    [TestClass]
    class AuthControllerTest
    {
        // not implemented in Pattern in Action.
        // see ShopControllerTest for a unit testing sample. 

    }
}
